<a href='./'><img src='webcontent/img/logo.png'/></a>
<ul>
    <li><a href='./'>Home</a></li>
    <li><a href='./about-us'>About Us</a></li>
</ul>