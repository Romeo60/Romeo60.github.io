<!DOCTYPE html>
<html lang="en">
    <head>       
        <title>Bumphub 2</title>
    </head>
    <body>
       
        
        <div class='wrapper'>
            <div id="container">
            <?php if(isset($body)) { ?><?php print $body; ?><?php } ?>
            </div>
        </div>
        
        
    </body>
</html>